import FraudTutor from "./components/tutor/FraudTutor";

export default function App() {
  return <FraudTutor />;
}
