export type Question = {
  type: "mcq" | "truefalse";
  question: string;
  options?: string[];
  answer: string;
};

export type LessonItem =
  | { kind: "card"; title: string; content: string }
  | { kind: "question"; data: Question };

export type Course = {
  id: string;
  title: string;
  icon: string;
  lessons: LessonItem[];
};

export const courses: Course[] = [
  {
    id: "phone",
    title: "Phone Call Scams",
    icon: "📞",
    lessons: [
      {
        kind: "card",
        title: "Fake Bank Calls",
        content: "Banks never ask OTP or CVV on phone calls."
      },
      {
        kind: "question",
        data: {
          type: "truefalse",
          question: "A bank employee can ask for your OTP on call.",
          answer: "False"
        }
      }
    ]
  },

  {
    id: "sms",
    title: "SMS & WhatsApp Scams",
    icon: "💬",
    lessons: []
  },

  {
    id: "upi",
    title: "UPI & Payment Scams",
    icon: "💳",
    lessons: []
  },

  {
    id: "identity",
    title: "Identity & Document Scams",
    icon: "🪪",
    lessons: []
  }
];
