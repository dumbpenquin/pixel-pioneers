import { useState } from "react";
import CourseList from "./CourseList";
import type { Course } from "../../data/courses.ts";

export default function FraudTutor() {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  return (
    <div style={{ minHeight: "100vh", background: "#0B0F14" }}>
      {!selectedCourse && <CourseList onSelect={setSelectedCourse} />}

      {selectedCourse && (
        <div style={{ color: "white", padding: 30 }}>
          <h2>{selectedCourse.title}</h2>
          <p>Lesson player will appear here next.</p>
        </div>
      )}
    </div>
  );
}
