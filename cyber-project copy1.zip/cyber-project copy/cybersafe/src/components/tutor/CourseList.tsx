import { courses } from "../../data/courses.ts";
import type { Course } from "../../data/courses.ts";

type Props = {
  onSelect: (course: Course) => void;
};

export default function CourseList({ onSelect }: Props) {
  return (
    <div style={{ padding: 30 }}>
      <h1 style={{ color: "white" }}>Choose a Course</h1>

      <div style={{ display: "grid", gap: 16, marginTop: 20 }}>
        {courses.map((course) => (
          <div
            key={course.id}
            onClick={() => onSelect(course)}
            style={{
              background: "#1C1F2A",
              padding: 20,
              borderRadius: 12,
              cursor: "pointer",
              color: "white",
              border: "1px solid #2A2E3B"
            }}
          >
            <h3>
              {course.icon} {course.title}
            </h3>
          </div>
        ))}
      </div>
    </div>
  );
}
