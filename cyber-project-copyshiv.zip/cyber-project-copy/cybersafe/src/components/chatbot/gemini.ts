import { GoogleGenerativeAI } from '@google/generative-ai';
import { getReportingInfo, fraudReportingData } from '../../data/fraudReporting';

// Initialize Gemini AI
let genAI: GoogleGenerativeAI | null = null;

function initializeGemini() {
  // Only initialize once
  if (genAI) {
    return genAI;
  }
  
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  
  // Check if API key exists and is valid
  if (!apiKey) {
    console.warn('VITE_GEMINI_API_KEY not found in environment variables');
    return null;
  }
  
  const trimmedKey = apiKey.trim();
  
  if (!trimmedKey || trimmedKey === 'your_gemini_api_key_here' || trimmedKey.length < 20) {
    console.warn('Gemini API key appears to be invalid or placeholder');
    return null;
  }
  
  try {
    genAI = new GoogleGenerativeAI(trimmedKey);
    console.log('Gemini AI initialized successfully');
    return genAI;
  } catch (error) {
    console.error('Error initializing Gemini:', error);
    return null;
  }
}

// Enhanced system prompt with fraud reporting capabilities - encourages natural, varied responses
const SYSTEM_PROMPT = `You are CyberGuard, a friendly and knowledgeable cybersecurity assistant helping people in India stay safe from fraud and scams.

Your personality:
- Conversational, empathetic, and approachable
- Adapt your tone based on the user's urgency and emotional state
- Vary your responses - never repeat the exact same wording for similar questions
- Use natural language, not robotic templates
- Show genuine concern for the user's safety

Your expertise:
- Cybersecurity, fraud prevention, and scam identification
- Indian laws, authorities, and reporting procedures
- Banking, UPI, and financial fraud
- Phone, SMS, WhatsApp, and online scams
- Identity theft and document security

When helping users:
1. Understand their specific situation first - ask clarifying questions if needed
2. Provide personalized advice based on their context
3. Always include relevant contact information when discussing reporting
4. Format important details clearly: use **bold** for headings, numbers for steps, bullet points for lists
5. For phone numbers, use format: 📞 1930 or 📞 100
6. For websites, use format: 🔗 cybercrime.gov.in (as clickable links)
7. For emails, use format: ✉️ contact@example.com

Key contacts to reference when relevant:
- Cyber Crime: 1930 or cybercrime.gov.in
- Police Emergency: 100
- Banking: Contact bank first, then RBI Banking Ombudsman
- UPI Fraud: NPCI at npci.org.in
- Phone Scams: Sanchar Saathi (sancharsaathi.gov.in) or TRAI
- Identity Theft: UIDAI helpline 1947 or uidai.gov.in
- Consumer Issues: 1915 or consumerhelpline.gov.in
- Investment Fraud: SEBI 1800 266 7575 or scores.gov.in
- Women Helpline: 1091
- Child Helpline: 1098

Important guidelines:
- Never give identical responses - always vary your wording and approach
- Be conversational and natural, not formulaic
- Respond based on the specific user question, not generic templates
- If the user seems distressed, be more supportive and urgent
- If they're asking for general info, be informative but friendly
- Keep responses focused but comprehensive when needed
- Use emojis sparingly and naturally (🤖 📞 🔗 ✉️ ⚠️)`;

interface Message {
  role: 'user' | 'bot';
  text: string;
}

export async function sendToGemini(userMessage: string, conversationHistory: Message[] = []): Promise<string> {
  try {
    // Initialize Gemini if API key is available
    const ai = initializeGemini();
    
    if (!ai) {
      console.warn('Gemini AI not initialized - API key missing or invalid');
      // Only use minimal fallback if API key is not available
      return getMinimalFallbackResponse(userMessage);
    }

    const model = ai.getGenerativeModel({ 
      model: 'gemini-1.5-flash',
      systemInstruction: SYSTEM_PROMPT,
      generationConfig: {
        temperature: 0.8, // Higher temperature for more varied, creative responses
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024,
      },
    });

    // Build conversation history for context (last 4 exchanges = 8 messages to keep it manageable)
    const recentHistory = conversationHistory.slice(-8);
    
    let text: string;
    
    try {
      // Use chat session if we have history, otherwise use simple generateContent
      if (recentHistory.length > 0 && recentHistory.length % 2 === 0) {
        // Only use chat if we have complete pairs of user/bot messages
        try {
          const chat = model.startChat({
            history: recentHistory.map(msg => ({
              role: msg.role === 'user' ? 'user' : 'model',
              parts: [{ text: msg.text }],
            })),
          });

          // Generate response with conversation context
          const result = await chat.sendMessage(userMessage);
          const response = await result.response;
          text = response.text();
        } catch (chatError: any) {
          console.warn('Error with chat session, falling back to simple generation:', chatError?.message);
          // Fallback to simple generation if chat session fails
          const result = await model.generateContent(userMessage);
          const response = await result.response;
          text = response.text();
        }
      } else {
        // Simple generation for first message or incomplete history
        const result = await model.generateContent(userMessage);
        const response = await result.response;
        text = response.text();
      }
    } catch (apiError: any) {
      console.error('Gemini API error:', apiError);
      throw new Error(`Gemini API error: ${apiError?.message || 'Unknown error'}. Please check your API key and internet connection.`);
    }

    // Post-process: Ensure important contacts are included if discussing reporting
    // Only enhance minimally if AI completely missed reporting information
    const reportingKeywords = extractReportingKeywords(userMessage);
    const reportingInfo = getReportingInfo(reportingKeywords);
    
    // Only enhance if AI didn't include contacts and user clearly asked about reporting
    if (reportingInfo && reportingKeywords.length >= 2 && 
        !text.toLowerCase().includes('1930') && !text.toLowerCase().includes('cybercrime') && 
        !text.includes('http') && !text.includes('@')) {
      // Subtle enhancement - let AI handle it naturally first
      text += '\n\n' + formatReportingGuidance(reportingInfo);
    }

    return text;
  } catch (error: any) {
    console.error('Error calling Gemini API:', error);
    
    // Provide more specific error messages
    let errorMessage = 'I encountered an error while processing your request. ';
    
    if (error?.message?.includes('API_KEY')) {
      errorMessage += 'There seems to be an issue with the API key. Please check your .env file.';
    } else if (error?.message?.includes('quota') || error?.message?.includes('limit')) {
      errorMessage += 'The API quota may have been exceeded. Please try again later.';
    } else if (error?.message?.includes('network') || error?.message?.includes('fetch')) {
      errorMessage += 'Network error. Please check your internet connection and try again.';
    } else {
      errorMessage += `Error: ${error?.message || 'Unknown error'}.`;
    }
    
    errorMessage += '\n\n**For urgent fraud reporting:**\n\n';
    errorMessage += '• Cyber Crime Helpline: 1930\n';
    errorMessage += '• Police Emergency: 100\n';
    errorMessage += '• Cyber Crime Portal: cybercrime.gov.in';
    
    return errorMessage;
  }
}

function extractReportingKeywords(message: string): string[] {
  const lowerMessage = message.toLowerCase();
  const keywords: string[] = [];
  
  const keywordMap: Record<string, string[]> = {
    report: ['report', 'reporting', 'file', 'complaint', 'complain'],
    fraud: ['fraud', 'scam', 'fraudulent'],
    cybercrime: ['cybercrime', 'cyber crime', 'online fraud', 'internet fraud'],
    banking: ['bank', 'banking', 'upi', 'payment', 'transaction', 'atm', 'card'],
    phone: ['phone', 'call', 'vishing', 'telephone'],
    identity: ['identity', 'aadhaar', 'document', 'pan', 'sim'],
    online: ['online', 'shopping', 'ecommerce', 'website', 'delivery'],
    investment: ['investment', 'crypto', 'stock', 'ponzi', 'scheme'],
  };

  for (const [category, terms] of Object.entries(keywordMap)) {
    if (terms.some(term => lowerMessage.includes(term))) {
      keywords.push(category, ...terms.filter(term => lowerMessage.includes(term)));
    }
  }

  return keywords;
}

function formatReportingGuidance(info: typeof fraudReportingData[keyof typeof fraudReportingData]): string {
  let guidance = `\n\n**📋 Reporting ${info.category}**\n\n`;
  
  guidance += `**Authorities to Contact:**\n\n`;
  info.authorities.forEach((auth, index) => {
    guidance += `${index + 1}. ${auth.name}\n`;
    if (auth.type === 'helpline') {
      guidance += `   Contact: ${auth.contact}\n`;
    } else if (auth.type === 'website') {
      guidance += `   Website: ${auth.contact}\n`;
    } else if (auth.type === 'email') {
      guidance += `   Email: ${auth.contact}\n`;
    }
    if (auth.description) {
      guidance += `   ${auth.description}\n`;
    }
    guidance += '\n';
  });

  guidance += `**Steps to Report:**\n\n`;
  info.steps.forEach((step, index) => {
    guidance += `${index + 1}. ${step}\n`;
  });

  return guidance;
}

// Minimal fallback only when API is unavailable - encourages getting API key
function getMinimalFallbackResponse(_message: string): string {
  return `I'm currently unable to connect to my AI service. To get the best assistance, please configure your Gemini API key.\n\n` +
         `**For urgent fraud reporting:**\n\n` +
         `• Cyber Crime Helpline: 1930\n` +
         `• Police Emergency: 100\n` +
         `• Cyber Crime Portal: cybercrime.gov.in\n\n` +
         `To enable full AI assistance, add your Gemini API key to the .env file. See README.md for setup instructions.`;
}