import { useState, useRef, useEffect } from "react";
import { sendToGemini } from "./gemini";
import FormattedMessage from "./FormattedMessage";

export default function Chatbot({ onClose }: { onClose: () => void }) {
  const [messages, setMessages] = useState<{ role: string; text: string }[]>([
    { role: "bot", text: "**Hello! I'm CyberGuard 🤖**\n\nI'm your cybersecurity assistant. I can help you with:\n\n• Understanding different types of scams\n• Learning how to protect yourself from fraud\n• **Guiding you on how to report fraud** with specific contacts\n• Providing authority phone numbers and websites\n\nWhat would you like to know about, or do you need help reporting something?" }
  ]);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  async function send() {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();

    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setInput("");
    setLoading(true);

    try {
      // Pass conversation history for context-aware responses
      const conversationHistory = messages.map(m => ({
        role: m.role as 'user' | 'bot',
        text: m.text
      }));
      
      const reply = await sendToGemini(userMsg, conversationHistory);
      setMessages(prev => [...prev, { role: "bot", text: reply }]);
    } catch (error: any) {
      console.error('Chatbot error:', error);
      const errorMsg = error?.message || 'Unknown error occurred';
      setMessages(prev => [...prev, { 
        role: "bot", 
        text: `I encountered an error: ${errorMsg}\n\n**For urgent fraud reporting:**\n\n• Cyber Crime Helpline: 1930\n• Police Emergency: 100\n• Cyber Crime Portal: cybercrime.gov.in\n\nPlease check the browser console for more details and ensure your API key is correctly configured.` 
      }]);
    } finally {
      setLoading(false);
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", handleEscape);
    // Prevent body scroll when modal is open
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "unset";
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Chatbot Modal */}
      <div 
        className="relative w-full max-w-lg h-[85vh] max-h-[700px] bg-[#1C1F2A] border-2 border-[#2A2E3B] rounded-xl shadow-2xl text-white flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-[#2A2E3B] font-bold flex justify-between items-center bg-[#141821] rounded-t-xl">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🤖</span>
            <span>CyberGuard</span>
          </div>
          <button 
            onClick={onClose} 
            className="text-gray-400 hover:text-white hover:bg-[#2A2E3B] rounded-lg p-1 transition-colors text-xl w-8 h-8 flex items-center justify-center"
            aria-label="Close chatbot"
          >
            ✕
          </button>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 text-sm min-h-0 scrollbar-thin scrollbar-thumb-[#2A2E3B] scrollbar-track-transparent">
          {messages.map((m, i) => (
            <div 
              key={i} 
              className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] px-4 py-3 rounded-lg ${
                  m.role === "user" 
                    ? "bg-[#E63946] text-white" 
                    : "bg-[#141821] text-gray-200 border border-[#2A2E3B]"
                }`}
              >
                {m.role === "bot" ? (
                  <FormattedMessage text={m.text} />
                ) : (
                  <div className="whitespace-pre-wrap break-words">{m.text}</div>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-[#141821] px-4 py-2 rounded-lg border border-[#2A2E3B] text-gray-400">
                Typing...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 border-t border-[#2A2E3B] bg-[#141821] rounded-b-xl">
          <div className="flex gap-2">
            <input
              className="flex-1 bg-[#1C1F2A] border border-[#2A2E3B] rounded-lg px-4 py-2 outline-none focus:border-red-500 transition-colors text-white placeholder-gray-500"
              placeholder="Ask about scams, fraud, or online safety..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              disabled={loading}
              autoFocus
            />
            <button 
              onClick={send} 
              disabled={loading || !input.trim()}
              className="px-6 py-2 bg-[#E63946] hover:bg-[#c9323f] disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-semibold transition-colors"
            >
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
