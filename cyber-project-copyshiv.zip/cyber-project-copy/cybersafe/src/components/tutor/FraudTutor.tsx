import { useState } from "react";
import CourseList from "./CourseList.tsx";
import LessonPlayer from "./LessonPlayer.tsx";
import type { Course } from "../../data/courses.ts";

export default function FraudTutor() {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  return (
    <div style={{ minHeight: "100vh", color: "white", display: "flex" }}>

      {!selectedCourse && (
        <div style={{ width: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
          <CourseList onSelect={setSelectedCourse} />
        </div>
      )}

      {selectedCourse && (
        <div style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 32 }}>

          <button
            onClick={() => setSelectedCourse(null)}
            style={{
              marginBottom: 24,
              alignSelf: "flex-start",
              marginLeft: 40,
              borderRadius: 8,
              background: "#E63946",
              padding: "8px 16px",
              color: "white",
              border: "none",
              cursor: "pointer"
            }}
          >
            ← Back to Courses
          </button>

          <LessonPlayer course={selectedCourse} />

        </div>
      )}
    </div>
  );
}
