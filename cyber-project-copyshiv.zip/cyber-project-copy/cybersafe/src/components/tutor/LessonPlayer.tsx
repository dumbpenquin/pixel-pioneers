import { useEffect, useState } from "react";
import type { Course, LessonItem } from "../../data/courses.ts";

type Props = { course: Course };

export default function LessonPlayer({ course }: Props) {
  const [index, setIndex] = useState(0);
  const [completed, setCompleted] = useState(false);

  const item = course.lessons[index];

  useEffect(() => {
    saveProgress(course.id, index);
    if (!item) setCompleted(true);
  }, [index, item]);

  if (completed) {
    const getCompletionMessage = (courseId: string, courseTitle: string) => {
      switch (courseId) {
        case "phone":
          return {
            title: "🛡️ Phone Defense Master!",
            message: `Congratulations! You've mastered the art of spotting phone call scams. No more falling for fake bank calls or police threats. Your vigilance just saved you from potential financial disaster. Keep that phone security shield up!`,
            emoji: "📞"
          };
        case "sms":
          return {
            title: "💬 Message Guardian!",
            message: `Outstanding work! You're now a WhatsApp and SMS scam detector extraordinaire. Those sneaky links and urgent messages won't fool you anymore. Your digital literacy just leveled up significantly!`,
            emoji: "📱"
          };
        case "upi":
          return {
            title: "💰 Payment Protector!",
            message: `Brilliant! You've become a UPI and payment scam expert. Fake QR codes, suspicious transactions, and payment app tricks can't touch you now. Your financial fortress is impenetrable!`,
            emoji: "🏦"
          };
        case "identity":
          return {
            title: "🛡️ Identity Champion!",
            message: `Exceptional achievement! You're now a document and identity theft prevention specialist. Fake Aadhaar, forged documents, and identity scams stand no chance against your newfound knowledge. Stay vigilant, stay safe!`,
            emoji: "🔐"
          };
        default:
          return {
            title: "🎉 Course Completed!",
            message: `You finished ${courseTitle}`,
            emoji: "✅"
          };
      }
    };

    const completion = getCompletionMessage(course.id, course.title);

    return (
      <div style={{ marginTop: 80, borderRadius: 16, backgroundColor: '#1C1F2A', padding: 40, textAlign: 'center', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)' }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>{completion.emoji}</div>
        <h2 style={{ fontSize: 28, marginBottom: 16, color: '#E63946', fontWeight: 'bold' }}>{completion.title}</h2>
        <p style={{ fontSize: 16, lineHeight: 1.6, color: '#B0B3C0', maxWidth: 500, margin: '0 auto' }}>{completion.message}</p>
        <div style={{ marginTop: 24, fontSize: 14, color: '#6366F1', fontStyle: 'italic' }}>
          Keep learning • Stay safe • Protect others
        </div>
      </div>
    );
  }

  if (!item) return null;

  return (
    <div style={{ marginTop: 40, width: '100%', display: 'flex', justifyContent: 'center' }}>

      <div style={{ maxWidth: 576, width: '100%', borderRadius: 16, border: '1px solid #2A2E3B', backgroundColor: 'rgba(28, 31, 42, 0.9)', backdropFilter: 'blur(24px)', padding: 32, boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' }}>

        <ProgressBar current={index + 1} total={course.lessons.length} />

        {item.kind === "card" && (
          <>
            <h3 style={{ fontSize: 20, fontWeight: 600, marginBottom: 12 }}>{item.title}</h3>
            <p style={{ color: '#B0B3C0', marginBottom: 24, lineHeight: 1.625 }}>{item.content}</p>

            <button
              onClick={() => setIndex(index + 1)}
              style={{ borderRadius: 8, backgroundColor: '#E63946', padding: '8px 24px', fontWeight: 600, transition: 'background-color 0.2s' }}
            >
              Continue →
            </button>
          </>
        )}

        {item.kind === "question" && (
          <QuestionCard item={item} onNext={() => setIndex(index + 1)} />
        )}

      </div>

    </div>
  );
}

/* ---------------------- */

function QuestionCard({ item, onNext }: { item: LessonItem; onNext: () => void }) {
  if (item.kind !== "question") return null;

  const q = item.data;
  const [correct, setCorrect] = useState<boolean | null>(null);

  function check(ans: string) {
    setCorrect(ans === q.answer);
  }

  const options =
    q.type === "truefalse" ? (q.options || ["True", "False"]) : q.options || [];

  return (
    <>
      <h3 style={{ fontSize: 18, marginBottom: 16 }}>{q.question}</h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {options.map((o) => (
          <div
            key={o}
            onClick={() => check(o)}
            style={{ cursor: 'pointer', borderRadius: 8, backgroundColor: '#141821', padding: '8px 16px', transition: 'background-color 0.2s' }}
          >
            {o}
          </div>
        ))}
      </div>

      {correct !== null && (
        <>
          <p style={{ marginTop: 16, color: correct ? '#4ade80' : '#f87171' }}>
            {correct ? "Correct!" : "Wrong!"}
          </p>

          <button
            onClick={onNext}
            style={{ marginTop: 16, borderRadius: 8, backgroundColor: '#E63946', padding: '8px 24px', fontWeight: 600, transition: 'background-color 0.2s' }}
          >
            Continue →
          </button>
        </>
      )}
    </>
  );
}

/* ---------------------- */

function ProgressBar({ current, total }: { current: number; total: number }) {
  const percent = (current / total) * 100;

  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ height: 8, width: '100%', borderRadius: 4, backgroundColor: '#2A2E3B', overflow: 'hidden' }}>
        <div
          style={{ height: '100%', backgroundColor: '#E63946', transition: 'width 0.3s ease', width: `${percent}%` }}
        />
      </div>
    </div>
  );
}

function saveProgress(courseId: string, index: number) {
  const raw = localStorage.getItem("fraudTutorProgress");
  const data = raw ? JSON.parse(raw) : {};
  data[courseId] = index;
  localStorage.setItem("fraudTutorProgress", JSON.stringify(data));
}
