import { courses } from "../../data/courses.ts";
import type { Course } from "../../data/courses.ts";

type Props = {
  onSelect: (course: Course) => void;
};

export default function CourseList({ onSelect }: Props) {
  return (
    <div style={{ padding: 30, maxWidth: 800, margin: "0 auto" }}>
      <h1 style={{
        color: "#E63946",
        textAlign: "center",
        marginBottom: 30,
        fontSize: 42,
        fontWeight: "bold",
        fontFamily: "monospace",
        textTransform: "uppercase",
        letterSpacing: "3px",
        textShadow: "0 0 10px rgba(230, 57, 70, 0.5), 0 0 20px rgba(230, 57, 70, 0.3)",
        borderBottom: "3px solid #E63946",
        paddingBottom: 10,
        display: "inline-block",
        marginLeft: "auto",
        marginRight: "auto"
      }}>CYBER DEFENSE COURSES</h1>

      <div style={{ display: "grid", gap: 20, marginTop: 20, gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))" }}>
        {courses.map((course) => (
          <div
            key={course.id}
            onClick={() => onSelect(course)}
            style={{
              background: "#1C1F2A",
              padding: 24,
              borderRadius: 16,
              cursor: "pointer",
              color: "white",
              border: "2px solid #2A2E3B",
              transition: "all 0.3s ease",
              boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
              textAlign: "center"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "#E63946";
              e.currentTarget.style.transform = "translateY(-4px)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "#2A2E3B";
              e.currentTarget.style.transform = "translateY(0)";
            }}
          >
            <div style={{ fontSize: 48, marginBottom: 12 }}>{course.icon}</div>
            <h3 style={{ margin: 0, fontSize: 20, fontWeight: "bold" }}>
              {course.title}
            </h3>
          </div>
        ))}
      </div>
    </div>
  );
}

