import { useState } from "react";
import CyberBackground from "./components/ui/CyberBackground";
import FraudTutor from "./components/tutor/FraudTutor";
import Chatbot from "./components/chatbot/Chatbot";
import ScamsPage from "./components/scams/ScamsPage";

export default function App() {
  const [currentView, setCurrentView] = useState<"home" | "courses" | "scams">("home");
  const [showChatbot, setShowChatbot] = useState(false);

  if (currentView === "courses") {
    return (
      <CyberBackground>
        <div className="relative">
          <button
            onClick={() => setCurrentView("home")}
            className="absolute top-6 left-6 z-20 bg-[#E63946] hover:bg-[#c9323f] text-white px-6 py-3 rounded-lg font-semibold transition-colors shadow-lg"
          >
            ← Back to Home
          </button>
          <FraudTutor />
        </div>
      </CyberBackground>
    );
  }

  if (currentView === "scams") {
    return (
      <CyberBackground>
        <div className="relative">
          <button
            onClick={() => setCurrentView("home")}
            className="absolute top-6 left-6 z-20 bg-[#E63946] hover:bg-[#c9323f] text-white px-6 py-3 rounded-lg font-semibold transition-colors shadow-lg"
          >
            ← Back to Home
          </button>
          <ScamsPage />
        </div>
      </CyberBackground>
    );
  }

  return (
    <CyberBackground>
      <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12 relative">
        <div className="max-w-4xl w-full text-center space-y-8">
          {/* Header */}
          <div className="space-y-4">
            <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-red-400 to-red-600">
              CYBERSAFE
            </h1>
            <p className="text-xl text-gray-300">
              Protect yourself from online scams and fraud
            </p>
          </div>

          {/* Main Action Cards */}
          <div className="grid md:grid-cols-2 gap-6 mt-12">
            {/* Courses Card */}
            <div
              onClick={() => setCurrentView("courses")}
              className="bg-[#1C1F2A] border-2 border-[#2A2E3B] rounded-xl p-8 cursor-pointer transition-all duration-300 hover:border-red-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-red-500/20 active:scale-95"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setCurrentView("courses");
                }
              }}
            >
              <div className="text-6xl mb-4">📚</div>
              <h2 className="text-2xl font-bold mb-3 text-red-400">
                Cyber Defense Courses
              </h2>
              <p className="text-gray-400">
                Learn to identify and protect yourself from phone calls, SMS,
                UPI, and identity scams through interactive lessons
              </p>
            </div>

            {/* Chatbot Card */}
            <div
              onClick={() => setShowChatbot(true)}
              className="bg-[#1C1F2A] border-2 border-[#2A2E3B] rounded-xl p-8 cursor-pointer transition-all duration-300 hover:border-blue-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-500/20 active:scale-95"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setShowChatbot(true);
                }
              }}
            >
              <div className="text-6xl mb-4">🤖</div>
              <h2 className="text-2xl font-bold mb-3 text-blue-400">
                Cyber Assistant
              </h2>
              <p className="text-gray-400">
                Ask questions about online safety, scams, and how to protect
                yourself from fraud
              </p>
            </div>
          </div>

          {/* Most Common Scams Card */}
          <div className="mt-16">
            <div
              onClick={() => setCurrentView("scams")}
              className="bg-[#1C1F2A] border-2 border-[#2A2E3B] rounded-xl p-8 cursor-pointer transition-all duration-300 hover:border-orange-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-orange-500/20 active:scale-95 max-w-2xl mx-auto"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setCurrentView("scams");
                }
              }}
            >
              <div className="text-6xl mb-4 text-center">⚠️</div>
              <h2 className="text-3xl font-bold mb-3 text-orange-400 text-center">
                Most Common Scams
              </h2>
              <p className="text-gray-400 text-center">
                Explore 18+ common frauds and scams with detailed information, reporting steps, and authority contacts
              </p>
            </div>
          </div>

          {/* Footer Note */}
          <div className="mt-12 p-6 bg-red-500/10 border border-red-500/30 rounded-lg">
            <p className="text-red-400 font-semibold">
              ⚠️ Remember: Never share your OTP, UPI PIN, or personal documents
              with strangers, even if they claim to be from official sources.
            </p>
          </div>
        </div>
      </div>

      {/* Chatbot Modal */}
      {showChatbot && <Chatbot onClose={() => setShowChatbot(false)} />}
    </CyberBackground>
  );
}
